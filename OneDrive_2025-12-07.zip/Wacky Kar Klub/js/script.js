document.addEventListener('DOMContentLoaded', () => {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const items = document.querySelectorAll('.merch-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            const filter = button.getAttribute('data-filter');

            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            items.forEach(item => {
                if (filter === 'all' || item.getAttribute('data-category') === filter) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
});

//Banner for the SLIDESHOW 
document.addEventListener('DOMContentLoaded', function () {
    const banners = document.querySelectorAll('.slideshow-banner');
    
    banners.forEach(banner => {
        const slides = banner.querySelectorAll('img');
        if (slides.length <= 1) return; // no slideshow needed if only one image
        
        let current = 0;
        
        setInterval(() => {
            slides[current].classList.remove('active');
            current = (current + 1) % slides.length;
            slides[current].classList.add('active');
        }, 5000); // changes every 5 seconds
    });
});